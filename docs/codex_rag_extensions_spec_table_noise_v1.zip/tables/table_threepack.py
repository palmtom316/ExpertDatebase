from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Tuple
import re, html, json

@dataclass
class TableChunk:
    chunk_id: str
    doc_id: str
    page_no: int
    text: str
    payload: Dict[str, Any]

_title_re = re.compile(r"^\s*(表|TABLE)\s*(?P<no>\d+(?:\.\d+)*)\s*(?P<title>.+)$", re.IGNORECASE)

def infer_title(table_title: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    if not table_title:
        return None, None
    m = _title_re.match(table_title.strip())
    if not m:
        return None, table_title.strip()
    return m.group("no"), m.group("title").strip()

def html_table_to_rows(html_table: str) -> List[List[str]]:
    rows = []
    tr_parts = re.split(r"</tr\s*>", html_table, flags=re.IGNORECASE)
    for tr in tr_parts:
        if "<td" not in tr.lower():
            continue
        cells = re.split(r"</td\s*>", tr, flags=re.IGNORECASE)
        row = []
        for c in cells:
            m = re.search(r">(.+)$", c, flags=re.DOTALL)
            if not m:
                continue
            txt = re.sub(r"<[^>]+>", "", m.group(1))
            txt = html.unescape(txt).strip()
            if txt:
                row.append(txt)
        if row:
            rows.append(row)
    return rows

def build_table_summary(table_title: str, rows: List[List[str]]) -> str:
    parts = [table_title.strip()]
    if rows:
        parts.append("列：" + " / ".join(rows[0]))
        for r in rows[1:6]:
            parts.append(" | ".join(r))
    return "\n".join(parts)

def build_row_facts(rows: List[List[str]]) -> List[Dict[str, Any]]:
    if len(rows) < 2:
        return []
    header = rows[0]
    facts = []
    for r in rows[1:]:
        rec = {}
        for i, h in enumerate(header):
            if i < len(r):
                rec[h] = r[i]
        if rec:
            facts.append(rec)
    return facts

def build_table_threepack(doc_id: str, page_no: int, table_html: str, table_title: str, table_id: str) -> List[TableChunk]:
    rows = html_table_to_rows(table_html)
    tno, _ = infer_title(table_title)
    common = {"doc_id": doc_id, "page_no": page_no, "chunk_type": "table", "table_id": table_id, "table_no": tno, "table_title": table_title}

    chunks: List[TableChunk] = []
    chunks.append(TableChunk(chunk_id=f"{doc_id}::table_raw::{table_id}::{page_no}", doc_id=doc_id, page_no=page_no, text=table_html, payload={**common, "table_repr": "raw"}))
    summary = build_table_summary(table_title, rows)
    chunks.append(TableChunk(chunk_id=f"{doc_id}::table_summary::{table_id}::{page_no}", doc_id=doc_id, page_no=page_no, text=summary, payload={**common, "table_repr": "summary"}))
    for idx, rec in enumerate(build_row_facts(rows)):
        chunks.append(TableChunk(chunk_id=f"{doc_id}::table_row::{table_id}::{page_no}::{idx}", doc_id=doc_id, page_no=page_no, text=json.dumps(rec, ensure_ascii=False, separators=(",",":")), payload={**common, "table_repr": "row", "row": rec}))
    return chunks
