from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Optional
import difflib, re, html as _html

@dataclass
class TableBlock:
    doc_id: str
    page_no: int
    table_title: str
    table_html: str
    header_sig: str

def header_signature(table_html: str) -> str:
    m = re.search(r"<tr[^>]*>(.*?)</tr\s*>", table_html, flags=re.IGNORECASE|re.DOTALL)
    if not m:
        return ""
    row = re.sub(r"<[^>]+>", " ", m.group(1))
    row = _html.unescape(row)
    row = " ".join(row.split())
    return row[:200]

def similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()

def group_crosspage_tables(blocks: List[TableBlock], header_sim_min: float = 0.7, max_pages_gap: int = 1) -> Dict[str, List[TableBlock]]:
    groups: Dict[str, List[TableBlock]] = {}
    idx = 0
    prev: Optional[TableBlock] = None
    cur_id: Optional[str] = None
    for b in sorted(blocks, key=lambda x: (x.doc_id, x.page_no)):
        if prev and b.doc_id == prev.doc_id and (b.page_no - prev.page_no) <= max_pages_gap:
            if similarity(b.header_sig, prev.header_sig) >= header_sim_min or (b.table_title and b.table_title == prev.table_title):
                groups[cur_id].append(b)
                prev = b
                continue
        idx += 1
        cur_id = f"tbl_{idx:04d}"
        groups[cur_id] = [b]
        prev = b
    return groups

def stitch_table_group(group: List[TableBlock]) -> TableBlock:
    if not group:
        raise ValueError("empty group")
    base = group[0]
    merged = base.table_html
    for b in group[1:]:
        merged += "\n<!-- continued -->\n" + b.table_html
    return TableBlock(doc_id=base.doc_id, page_no=base.page_no, table_title=base.table_title, table_html=merged, header_sig=base.header_sig)
