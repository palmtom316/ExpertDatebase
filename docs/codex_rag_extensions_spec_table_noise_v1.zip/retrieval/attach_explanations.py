from __future__ import annotations
from typing import List, Dict, Any

def attach_explanations(hits: List[Dict[str, Any]], fetch_by_filter_fn, top_k_attach: int = 5) -> List[Dict[str, Any]]:
    out = list(hits)
    seen = {h.get("chunk_id") for h in hits}
    for h in hits[:top_k_attach]:
        payload = h.get("payload", {}) or {}
        cid = payload.get("clause_id")
        dt = payload.get("doc_type")
        if not cid or dt not in ("clause", "explanation"):
            continue
        target_dt = "explanation" if dt == "clause" else "clause"
        filt = {"must": [{"key": "clause_id", "match": {"value": cid}}, {"key": "doc_type", "match": {"value": target_dt}}]}
        sibs = fetch_by_filter_fn(filt, top_k=1) or []
        for s in sibs:
            sid = s.get("chunk_id")
            if sid and sid not in seen:
                out.append(s); seen.add(sid)
    out.sort(key=lambda hh: 0 if (hh.get("payload", {}).get("doc_type")=="clause") else 1)
    return out
