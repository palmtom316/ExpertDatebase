from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict, Any
import re

@dataclass
class Page:
    doc_id: str
    page_no: int
    text: str

@dataclass
class ExplanationNode:
    doc_id: str
    clause_id: str
    clause_id_base: str
    clause_sub: Optional[str]
    title: Optional[str]
    body: str
    page_start: int
    page_end: int

def parse_explanations_from_pages(pages: List[Page], explanation_start_regexes: List[str], clause_id_regex: str) -> List[ExplanationNode]:
    start_res = [re.compile(r, re.IGNORECASE) for r in explanation_start_regexes]
    id_re = re.compile(clause_id_regex)

    in_explain = False
    nodes: List[ExplanationNode] = []
    cur: Optional[ExplanationNode] = None
    buf: List[str] = []

    for p in pages:
        for ln in [x.strip() for x in p.text.splitlines() if x.strip()]:
            if not in_explain and any(r.search(ln) for r in start_res):
                in_explain = True
                continue
            if not in_explain:
                continue
            m = id_re.match(ln)
            if m:
                if cur:
                    cur.body = "\n".join(buf).strip()
                    cur.page_end = p.page_no
                    nodes.append(cur)
                buf = []
                base = m.group("id")
                sub = m.groupdict().get("sub")
                rest = (m.groupdict().get("rest") or "").strip()
                clause_id = base + (f"({sub})" if sub else "")
                title = rest if rest and len(rest) <= 60 and not rest.endswith(("。",".","；",";","：",":")) else None
                if title is None and rest:
                    buf.append(rest)
                cur = ExplanationNode(doc_id=p.doc_id, clause_id=clause_id, clause_id_base=base, clause_sub=sub, title=title, body="", page_start=p.page_no, page_end=p.page_no)
            else:
                if cur:
                    buf.append(ln)

    if cur:
        cur.body = "\n".join(buf).strip()
        nodes.append(cur)
    return nodes

def node_to_dict(n: ExplanationNode) -> Dict[str, Any]:
    return asdict(n)
