from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Tuple
import re
from collections import Counter

@dataclass
class DenoiseStats:
    removed_by_regex: int
    removed_by_global_repeat: int
    kept: int

def denoise_pages_text(
    pages_text: List[str],
    reject_line_regexes: List[str],
    min_freq_ratio: float = 0.2,
    max_line_len: int = 50,
) -> Tuple[List[str], DenoiseStats, Dict[str, int]]:
    patterns = [re.compile(r, re.IGNORECASE) for r in reject_line_regexes]

    filtered_pages: List[List[str]] = []
    removed_by_regex = 0
    all_lines: List[str] = []

    for text in pages_text:
        kept_lines = []
        for line in text.splitlines():
            s = line.strip()
            if not s:
                continue
            if any(p.search(s) for p in patterns):
                removed_by_regex += 1
                continue
            kept_lines.append(s)
            if len(s) <= max_line_len:
                all_lines.append(s)
        filtered_pages.append(kept_lines)

    n_pages = max(1, len(pages_text))
    freq = Counter(all_lines)
    threshold = max(1, int(min_freq_ratio * n_pages))
    repeat_lines = {l: c for l, c in freq.items() if c >= threshold and len(l) <= max_line_len}

    removed_by_global = 0
    cleaned_pages = []
    for kept_lines in filtered_pages:
        out_lines = []
        for s in kept_lines:
            if s in repeat_lines:
                removed_by_global += 1
                continue
            out_lines.append(s)
        cleaned_pages.append("\n".join(out_lines))

    stats = DenoiseStats(
        removed_by_regex=removed_by_regex,
        removed_by_global_repeat=removed_by_global,
        kept=sum(1 for p in cleaned_pages for _ in p.splitlines() if _.strip())
    )
    return cleaned_pages, stats, repeat_lines
