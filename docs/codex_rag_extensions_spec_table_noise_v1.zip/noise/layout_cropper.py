from __future__ import annotations
from typing import List, Dict, Any

def crop_header_footer_blocks(blocks: List[Dict[str, Any]], page_height: float, top_ratio: float = 0.10, bottom_ratio: float = 0.10) -> List[Dict[str, Any]]:
    top_y = page_height * top_ratio
    bottom_y = page_height * (1.0 - bottom_ratio)
    kept = []
    for b in blocks:
        bbox = b.get("bbox") or b.get("box") or b.get("rect")
        if not bbox or len(bbox) != 4:
            kept.append(b); continue
        x0,y0,x1,y1 = bbox
        if y1 <= top_y:
            continue
        if y0 >= bottom_y:
            continue
        kept.append(b)
    return kept
