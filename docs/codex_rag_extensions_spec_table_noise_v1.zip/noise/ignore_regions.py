from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class IgnoreRegion:
    x0: float; y0: float; x1: float; y1: float
    reason: str

def overlaps_ignore_regions(bbox: Tuple[float,float,float,float], regions: List[IgnoreRegion], page_w: float, page_h: float) -> bool:
    x0,y0,x1,y1 = bbox
    for r in regions:
        rx0,ry0,rx1,ry1 = r.x0*page_w, r.y0*page_h, r.x1*page_w, r.y1*page_h
        ix0,iy0 = max(x0,rx0), max(y0,ry0)
        ix1,iy1 = min(x1,rx1), min(y1,ry1)
        if ix1 <= ix0 or iy1 <= iy0:
            continue
        return True
    return False
