# 03 LLM 适配与路由（V1.0）

## 1. 统一内部协议
### LLMRequest
- task_type: embedding | ie_extract | table_repair | qa_generate | classify_assist
- messages (system/user/assistant) 或 input（embedding/表格）
- temperature/max_tokens/top_p（可选）
- metadata: doc_id, user_role, request_id, dataset_version, prompt_version
### LLMResponse
- text / json
- usage(tokens_in/out, cost opt)
- provider/model
- latency_ms
- raw(opt)

## 2. Provider Adapter
- OpenAICompatibleAdapter（优先实现，兼容国内中转站）
- ClaudeAdapter（预留骨架）
- GeminiAdapter（预留骨架）

## 3. 路由策略（Tier1/Tier2/Tier3）
- Tier1：国内主力（稳定、合规）
- Tier2：国内备选（不同强项）
- Tier3：国外模型国内中转站（兜底）

默认路由（示例）：
- embedding: Tier1 -> Tier2 -> Tier3
- ie_extract: Tier1(稳定JSON) -> Tier2 -> Tier3(电力/复杂兜底)
- table_repair: Tier2(表格强) -> Tier1 -> Tier3
- qa_generate: Tier1(表达强) -> Tier3 -> Tier2

## 4. 安全与审计
- 对外发（LLM/embedding）文本默认脱敏
- 不允许发送整本PDF，仅章节/证据块/单表格
- 全部调用记录 llm_call_log（provider/model/latency/tokens/error）
