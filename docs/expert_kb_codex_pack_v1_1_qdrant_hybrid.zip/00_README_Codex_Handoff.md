# Expert库（知识库+资产库）项目：Codex/Claude 编码交付包（V1.0）
日期：2026-02-28
部署：Docker（局域网）
LLM：国内厂商/平台为主 + 国外商家国内中转站API接口（OpenAI/Claude/Gemini 风格兼容）
输入：PDF（扫描件为主，中文为主，含表格）
目标：形成专家库（知识库+资产库），支持对话式查询、强引用、可抽查；预留投标文件生成模块接入接口（暂不实现）。

---

## 1. 你现在如何用 Codex 开始编码（建议工作流）
1. **创建仓库骨架**：按 `01_Architecture_and_Modules.md` 的模块拆分建目录。
2. **优先实现文档流水线**：MinerU→标准化→章节→关键表格→chunk→embedding→IE→入库→抽查页面。
3. **先跑通最小闭环（MVP）**：
   - 上传PDF → 解析产物可查看 → chunks可检索 → QA回答带引用 → IE资产可查询
4. **再做评估平台（管理员页）**：实现 eval-runner + scorer + 仪表盘（IE优先）。
5. **模型适配层**：实现 OpenAI-compatible adapter 作为第一优先，预留 Claude/Gemini adapter 骨架。

> 建议：让 Codex 先完成后端数据结构、任务队列、worker流水线；前端先做最小抽查页（PDF页跳转+字段卡片+选择摘录）。

---

## 2. 交付物索引（本压缩包内容）
- `01_Architecture_and_Modules.md`：总体架构、模块清单、Docker部署建议
- `02_PDF_Processing_Pipeline_MinerU.md`：MinerU后处理详细流程（章节级+退化策略C）
- `03_LLM_Adapters_and_Routing.md`：LLM适配与路由（国内+中转站）
- `04_Extraction_Prompts_and_Schemas.md`：字段抽取提示词标准（含电力专项）与JSON schema建议
- `05_Evaluation_Visualization_Admin.md`：评估仪表盘（管理员页）设计
- `06_Datasets_and_Scoring.md`：测试集规范与评分算法（IE/TABLE/QA/RETR）
- `07_Labeling_Workflow_and_EvalRunner.md`：抽查即标注、评测执行器设计
- `08_Excerpt_Selector_and_Diff_Format.md`：摘录选择器实现要点 + diff_report格式
- `configs/keyword_rules_v1.yaml`：字段关键词规则（含电力专项）
- `configs/page_type_rules_v1.yaml`：页类型检测规则 + 字段页类型优先级映射
- `configs/ie_schema_v1.json`：IE抽取统一schema（建议）
- `configs/table_columns_v1.json`：三类关键表格列定义
- `configs/routing_policy_v1.json`：任务路由模板（Tier1/Tier2/Tier3）
- `docker/docker-compose.skeleton.yml`：Compose骨架（按你们环境调整）
- `09_Qdrant_Hybrid_Search_Spec.md`：Qdrant混合检索一页规范（collection schema + filter示例 + build_payload/parse_filter_spec伪代码）

---

## 3. MVP验收（建议）
- 上传一份PDF → 解析成功（MinerU内网）→ 章节树可查看
- 关键表格（设备/人员/业绩汇总）至少能落库一种
- 向量检索问答：返回答案 + 1~N条引用（文档+页码+摘录） + 可展开上下文
- IE抽取：至少资质/人员/业绩其中一类字段入库，带 source_page+excerpt
