# 08 摘录选择器与diff格式（V1.0）

## 1. 摘录选择器（管理员抽查/标注）
- 字段卡片按钮：选择摘录/展开上下文/跳转PDF页
- 默认“块摘录”：候选blocks/tables top5，点击即填excerpt
- 可选“自由选文本”：记录char_start/end
- excerpt结构统一：doc_id,page_no,source_type,block_id/table_id,row_index,excerpt,context_before,context_after

## 2. PDF定位
- 有bbox：可画框高亮（增强）
- 无bbox：跳页 + 在block文本中高亮excerpt（V1.0必做）

## 3. diff_report（JSON）
- 顶层：run_id/sample_id/task_type/provider/model/score_total/breakdown/errors/diff
- IE：diff_fields（hit/wrong/miss/hallucination）+ truth/pred grounding
- TABLE：row_diffs（missing/extra/matched）+ cell_diffs
- QA：cite_hits/must_include_hits/refusal_hit/violations(unsupported_claim等)
- RET：returned/relevant_targets/hit@k/mrr
