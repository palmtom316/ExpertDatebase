# 02 MinerU 后处理流程（章节级 + 退化策略C）（V1.0）

## 1. MinerU 使用策略
- 内网 MinerU 为主
- 外部 MinerU API 为备（仅管理员手动触发，不自动）
- MinerU 产物：JSON + Markdown 都保存
- 关键：保留页码映射（page_no -> blocks/tables）

## 2. 流程总览
1) MinerU 解析（PDF -> mineru_result.json/md + page_map）
2) 标准化（normalized_blocks/tables）
3) 质量评估（A/B/C）
4) 文档分类/标签
5) 章节树构建（章节优先；退化：按页切 -> 合并到 4k~8k 字）
6) 关键表格识别与结构化：设备清单/人员清单/业绩汇总（失败则LLM修复）
7) 章节内 chunking（500~800字）
8) embedding API 向量化入库
9) LangExtract IE 字段抽取入库（资产库，含电力专项字段）
10) 抽查产物生成（PDF跳页+高亮；可生成HTML review）
11) 定时巡检（资质临期等）

## 3. 标准化中间态（强制）
### Blocks
- block_id, page_no, block_type(title/paragraph/list/table_ref), text, order_in_page, bbox?(opt), confidence?(opt)
### Tables
- table_id, page_no, raw_text, cells?(opt), bbox?(opt), order_in_page, table_kind?(later)

## 4. 章节树构建（C：先页后合并）
- 识别标题：MinerU heading + 规则（第X章/一、/1.1）
- 若标题识别差：
  - Step A：每页一个临时chapter
  - Step B：按目标长度合并：4000~8000字，尽量不跨弱标题边界
- 章节记录：chapter_id,parent_id,title,level,start_page,end_page,block_ids,text_path,status(normal/degenerate)

## 5. 关键表格（三类）
- table_kind 分类器：通过表头关键词/章节标题/doc_type
- 结构化优先级：MinerU cells > LLM行列重建 > raw_text降级（标structured=false）
- 落库：equipment_items / person_table_items / project_summary_table
- 每行必须带 source_page

## 6. 强引用与可展开证据块
- 所有 chunks/资产字段必须带 page_no 或 page_range + excerpt
- QA 返回：citations[] + expandable_evidence[]（before/excerpt/after）

## 7. 失败重试与回退
- 内网MinerU失败：重试2次（参数变体：dpi/去噪/旋转）
- 仍失败：C级，进入人工处理队列；外部MinerU仅管理员手动
