# 01 总体架构与模块拆分（V1.0）

## 1. 目标
- 内网 Docker 部署专家库系统（知识库+资产库）
- 支持多LLM（国内厂商/平台为主，国外商家通过国内中转站API接口可用）
- PDF 输入为主（扫描件居多，中文，含表格）
- 过程产物可抽查（不审批）
- 强制引用：回答整体 1~N 条引用即可（文档+页码+摘录），支持展开上下文

## 2. 关键约束
- 系统内部使用，外网不可访问；但系统可出网访问 LLM API（经公司出口）
- 角色：系统管理员 / 投标工程师 / 公司员工
- 并发：3（LLM调用并发控制）
- 服务器：16核/64G/2T

## 3. Docker 组件建议（V1.0）
- web-ui（前端）
- api-server（鉴权/查询/对话编排/上传入口）
- worker（文档处理：MinerU、标准化、章节、表格、embedding、IE）
- scheduler（定时任务：资质临期巡检、评测任务调度）
- postgres（元数据/资产库/权限/审计/评测结果）
- minio（PDF与中间产物、评测数据集、diff报告）
- vector-db（Milvus 或 Qdrant）
- redis（队列与缓存）

## 4. 核心模块拆分（建议代码目录）
- /services/api-server
  - auth (RBAC)
  - upload
  - search (vector + filters)
  - chat (RAG + citations)
  - admin (review + eval dashboard APIs)
  - config (routing/keywords/page_types)
- /services/worker
  - mineru_client (internal + external(manual))
  - normalize (blocks/tables/page_map)
  - quality_gate
  - classify
  - chapters (chapter tree + degrade strategy C)
  - table_struct (3 kinds + repair via LLM on-demand)
  - chunking
  - embedding_client (API)
  - ie_langextract (schema-based extraction)
  - expiry_scan
  - eval_runner (offline eval)
  - scorer
- /services/web-ui
  - upload
  - chat UI (citations + expandable evidence)
  - review UI (PDF + blocks/tables + fields + excerpt selector)
  - admin eval UI (dashboard)
- /shared
  - models (DB schemas)
  - configs (yaml/json policies)
  - utils (text normalize, date/num normalize)

## 5. 数据对象（高层）
- 文档（doc）-> 版本（version）-> 页（page）-> blocks/tables
- 章节（chapters：树结构）
- chunks（向量检索单元，带 doc_id/chapter_id/page_range/block_ids）
- 资产库（业绩/资质/人员/设备/规范）字段记录（带 source_page+excerpt）
- 关键表格三张表（设备/人员/业绩汇总）
- LLM 调用审计（llm_call_log）
- 评测（eval_run/eval_sample/eval_result + outputs + diff_report）
