# 07 标注流程与评测执行器设计（V1.0）

## 1. 抽查即标注
- 抽查页面为入口：字段/表格/问答均可“一键加入评测集”
- 生成 input.json + truth.json + manifest追加（jsonl）
- 固化：dataset_version / schema_version / prompt_template_version / keyword_rules_version

## 2. Eval Runner
- eval-runner worker 读取 manifest
- 对每个 model x sample 执行推理（复用LLM编排层；评测可固定模型不走主备）
- 产出：pred.json + diff_report.json（MinIO）
- 写入：eval_run/eval_result
- scorer 模块按任务打分

## 3. 并发与公平
- 默认并发2~4
- 评测默认 retry=0（保持可比性）
- 网络超时可配置重试1次（可选）
