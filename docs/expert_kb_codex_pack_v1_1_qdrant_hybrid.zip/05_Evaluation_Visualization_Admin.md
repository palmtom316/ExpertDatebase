# 05 LLM评估可视化（管理员页）（V1.0）

## 页面
1) 总览 Dashboard
2) IE字段抽取评估（含电力专项）
3) 表格评估
4) QA问答评估（强引用+可展开证据）
5) Retrieval/Embedding评估
（可选）错误案例库

## 数据来源
- 在线：llm_call_log（真实流量：延迟/成本/失败率）
- 离线：eval_run/eval_sample/eval_result（质量分）

## 核心表（建议）
- llm_call_log
- eval_run
- eval_sample
- eval_result（score_total, breakdown_json, output_path, diff_path）

## 路由联动（半自动提示）
- IE总分连续下降 -> 提示切备模型
- 表格CellAcc下降 -> table_repair切换表格强模型
- QA引用准确率下降 -> 检查证据包/切片策略
