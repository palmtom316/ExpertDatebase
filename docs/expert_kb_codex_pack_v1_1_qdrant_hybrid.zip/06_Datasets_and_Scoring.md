# 06 测试集规范与评分算法（V1.0）

## 1. 数据集目录结构
datasets/v1.0/
- manifests/*.jsonl
- inputs/{ie,table,qa,retrieval}/
- truth/{ie,table,qa,retrieval}/
- outputs/{run_id}/...

## 2. 样本类型
- IE：IE_PROJECT / IE_QUAL / IE_PERSON / IE_STANDARD / IE_POWER_PROJECT
- TABLE：TABLE_EQUIP / TABLE_PERSON / TABLE_PROJECT_SUMMARY
- QA：QA_FACT / QA_NEG（拒答）
- RET：RET_Q（检索命中）

## 3. 评分（0-100）
### IE
score = 40*Precision + 20*Recall + 20*SourceAcc + 10*JSONValid - HallPenalty + PowerBonus(0~10)
- 金额容差：±1% 或 ±1000元（取更大）
- 线路长度容差：±0.1 km
- 电压等级必须精确命中（常见10/35/110/220/500等）
### TABLE
score = 25*RowAcc + 25*ColAcc + 35*CellAcc + 15*NumAcc
### QA
score = 20*CitePresence + 30*CiteAcc + 30*FactAcc + 20*RefusalAcc
（出现unsupported_claim可额外扣分）
### Retrieval
score = 40*Hit@5 + 30*Hit@10 + 20*MRR + 10*LatencyScore
