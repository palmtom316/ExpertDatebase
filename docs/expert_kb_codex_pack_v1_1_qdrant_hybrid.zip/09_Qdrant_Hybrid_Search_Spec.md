# 09 Qdrant Hybrid Search 一页规范（V1.0）
日期：2026-02-28

目标：实现“既懂语义，又懂关系/数值条件”的混合检索：**向量相似度 + Qdrant payload 过滤**。  
已选：向量库 **Qdrant**；过滤采用 **B方案（ID/Hash）**。

---

## 1. Collection 设计（Qdrant）

### 1.1 Collection 名称
- `chunks_v1`：存储可检索 chunk（章节切片），每条记录包含：向量 + payload（元数据/关系标签/数值字段）。

### 1.2 Vector
- `name`: `text_embedding`
- `size`: 由 embedding 模型决定（例如 768 / 1024 / 1536）
- `distance`: `Cosine`

### 1.3 Payload 字段（类型/用途）
> 约定：**展示字段**给 UI/日志；**过滤字段**给 Hybrid Search。过滤一律走 `*_ids` / `rel_*` / `val_*`。

#### 基础定位（必备）
- `doc_id` (string)
- `doc_name` (string)
- `chunk_id` (string)
- `chapter_id` (string)
- `page_start` (int)
- `page_end` (int)
- `doc_type` (string)  // project_proof / qualification / person / equipment / standard / bid_history / tech_plan ...
- `page_type` (string) // 来自 page_type_rules_v1

#### 引用与证据（必备）
- `has_citation` (bool)  // true
- `excerpt` (string)     // 推荐：chunk 的核心证据摘要（短）
- `block_ids` (array<string>) // 可选

#### 实体展示字段（不用于过滤）
- `entity_person_names` (array<string>)
- `entity_project_names` (array<string>)
- `entity_equipment_names` (array<string>)

#### 实体过滤字段（B方案：稳定ID/Hash）
- `entity_person_ids` (array<string>)    // e.g. ["p:8f3a..."]
- `entity_project_ids` (array<string>)   // e.g. ["pr:19ab..."]
- `entity_equipment_ids` (array<string>) // e.g. ["e:77aa..."]

#### 关系过滤字段（打平标签）
> 分隔符统一使用 `|`（避免项目名含 `_`/空格/括号导致歧义）。
- `rel_person_role` (array<string>)
  - e.g. ["p:8f3a...|项目经理", "p:8f3a...|技术负责人"]
- `rel_person_project` (array<string>)
  - e.g. ["p:8f3a...|pr:19ab..."]
- `rel_person_role_project` (array<string>)
  - e.g. ["p:8f3a...|项目经理|pr:19ab..."]

#### 数值过滤字段（范围过滤）
- `val_voltage_kv` (int)          // 110/220/500...
- `val_contract_amount_w` (float) // 单位：万元
- `val_line_length_km` (float)    // 可选
- `val_capacity_mva` (float)      // 可选

> 多值：如需可加 `val_voltage_kv_list` (array<int>)。V1.0 建议单值：取 chunk 中最关键/最大值。

---

## 2. Payload Index（索引建议）
为提升过滤性能（高频字段），建议建立 payload index：

- exact/keyword：`doc_id`, `doc_type`, `page_type`, `entity_person_ids`, `entity_project_ids`, `rel_person_role`
- range：`val_voltage_kv`, `val_contract_amount_w`

> 不建索引也可跑通，但过滤规模上来会明显变慢。

---

## 3. Filter JSON 示例（Qdrant）

### 3.1 找“张建国”担任过“项目经理”且电压等级 >=110kV 的材料
```json
{
  "must": [
    { "key": "entity_person_ids", "match": { "any": ["p:8f3a..."] } },
    { "key": "rel_person_role", "match": { "any": ["p:8f3a...|项目经理"] } },
    { "key": "val_voltage_kv", "range": { "gte": 110 } }
  ]
}
```

### 3.2 找 220kV 且合同金额 >= 5000 万元（即 >=5000万元）的业绩证据
```json
{
  "must": [
    { "key": "doc_type", "match": { "value": "project_proof" } },
    { "key": "val_voltage_kv", "range": { "gte": 220 } },
    { "key": "val_contract_amount_w", "range": { "gte": 5000 } }
  ]
}
```

### 3.3 限定项目（project_id）下的全部材料（用于组卷）
```json
{
  "must": [
    { "key": "entity_project_ids", "match": { "any": ["pr:19ab..."] } }
  ]
}
```

---

## 4. worker：build_payload() 伪代码（chunk 入库阶段）

### 4.1 输入
- `chunk`: doc_id/doc_name/chunk_id/chapter_id/page_start/page_end/doc_type/text/block_ids
- `ie_assets`: 该章节/该页字段抽取结果（project/person/qualification/...）
- `relations_light`: 轻关系（优先：PERSON_TO_PROJECT、COMPANY_TO_QUALIFICATION）
- `entity_index`: Postgres 实体索引（name->stable_id/hash）
- `page_type`: 页类型检测结果（top_type）

### 4.2 输出
- `payload`（写入 Qdrant）

```python
def build_payload(chunk, ie_assets, relations_light, entity_index, page_type):
    payload = {
        "doc_id": chunk.doc_id,
        "doc_name": chunk.doc_name,
        "chunk_id": chunk.chunk_id,
        "chapter_id": chunk.chapter_id,
        "page_start": chunk.page_start,
        "page_end": chunk.page_end,
        "doc_type": chunk.doc_type,
        "page_type": page_type or "other",
        "has_citation": True,
        "excerpt": make_excerpt(chunk.text),
        "block_ids": chunk.block_ids or []
    }

    # ---------- entities (names + ids) ----------
    person_names = collect_person_names(ie_assets, relations_light, chunk.text)
    project_names = collect_project_names(ie_assets, relations_light, chunk.text)
    equip_names = collect_equipment_names(ie_assets, relations_light, chunk.text)

    payload["entity_person_names"] = unique(person_names)
    payload["entity_project_names"] = unique(project_names)
    payload["entity_equipment_names"] = unique(equip_names)

    payload["entity_person_ids"] = [entity_index.get_or_create_id("person", n) for n in payload["entity_person_names"]]
    payload["entity_project_ids"] = [entity_index.get_or_create_id("project", n) for n in payload["entity_project_names"]]
    payload["entity_equipment_ids"] = [entity_index.get_or_create_id("equipment", n) for n in payload["entity_equipment_names"]]

    # ---------- relations (flatten) ----------
    rel_person_role = []
    rel_person_project = []
    rel_person_role_project = []

    for rel in relations_light:
        if rel.type == "PERSON_TO_PROJECT":
            pid = entity_index.get_or_create_id("person", rel.source_name)
            prj = entity_index.get_or_create_id("project", rel.target_name)
            role = (rel.properties or {}).get("role_in_project")

            rel_person_project.append(f"{pid}|{prj}")
            if role:
                rel_person_role.append(f"{pid}|{role}")
                rel_person_role_project.append(f"{pid}|{role}|{prj}")

    payload["rel_person_role"] = unique(rel_person_role)
    payload["rel_person_project"] = unique(rel_person_project)
    payload["rel_person_role_project"] = unique(rel_person_role_project)

    # ---------- numeric (prefer IE, fallback regex) ----------
    payload["val_voltage_kv"] = infer_voltage_kv(ie_assets, chunk.text)        # int or None
    payload["val_contract_amount_w"] = infer_amount_wan(ie_assets, chunk.text) # float(万元) or None
    payload["val_line_length_km"] = infer_line_km(ie_assets, chunk.text)       # optional
    payload["val_capacity_mva"] = infer_capacity_mva(ie_assets, chunk.text)    # optional

    return payload
```

---

## 5. query：parse_filter_spec() 伪代码（规则抓 人名/角色/kV/金额 → Qdrant filter）

```python
import re

ROLE_KEYWORDS = ["项目经理","技术负责人","总工","安全员","质量员"]

def parse_amount_to_wan(text: str):
    # 5000万 / 0.5亿 / 800万元
    m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*(亿|万|万元)", text)
    if not m:
        return None
    v = float(m.group(1))
    unit = m.group(2)
    if unit == "亿":
        return v * 10000
    return v

def parse_filter_spec(question, entity_index):
    must = []

    m = re.search(r"(\d{2,3})\s*(kV|KV|千伏)", question)
    if m:
        kv = int(m.group(1))
        must.append({"key":"val_voltage_kv","range":{"gte":kv}})

    amount_w = parse_amount_to_wan(question)
    if amount_w is not None:
        must.append({"key":"val_contract_amount_w","range":{"gte":amount_w}})

    role_hit = next((r for r in ROLE_KEYWORDS if r in question), None)

    person_names = entity_index.match_names("person", question)
    for name in person_names:
        pid = entity_index.get_id("person", name)
        if pid:
            must.append({"key":"entity_person_ids","match":{"any":[pid]}})
            if role_hit:
                must.append({"key":"rel_person_role","match":{"any":[f"{pid}|{role_hit}"]}})

    filter_json = {"must": must} if must else None
    vector_query_text = build_vector_query_text(question, role_hit, m.group(0) if m else None)
    return filter_json, vector_query_text
```

---

## 6. Qdrant Search → citations（强引用 + 可展开上下文）

### 6.1 检索
1) `vector_query_text -> embedding -> query_vector`
2) `qdrant.search(collection="chunks_v1", vector=query_vector, filter=filter_json, limit=top_k)`

### 6.2 结果转 citations
每条命中返回：`doc_name`, `page_start/page_end`, `excerpt`，并可拼 `context_before/context_after`。  
回答输出：整体 **1~N 条引用**（按你们规则）。

---

## 7. 一致性与重建索引（reindex）
- payload 必须在 chunk 入库时生成；若后补 relations/entity_id，必须触发 `reindex_chunks(doc_id)`：重新 build_payload 并 upsert Qdrant。
