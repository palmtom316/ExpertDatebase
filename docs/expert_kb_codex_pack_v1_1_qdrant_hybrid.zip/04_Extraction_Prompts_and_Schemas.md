# 04 字段抽取提示词与Schema（V1.0）

## 1. 通用System Prompt（抽取原则）
- 仅基于输入文本，不猜测；缺失输出null
- 日期标准化 YYYY-MM-DD / YYYY-MM
- 金额提取原文 + RMB元（转换）
- 输出合法JSON，不含解释
- 必须 source_page；表格来源 source_type="table"

## 2. 文档类型字段（资产库）
### 业绩 project
- project_name, project_region, project_category
- contract_amount_original, contract_amount_rmb
- contract_sign_date, completion_date
- owner_unit, proof_type
- source_page + excerpt
### 资质 qualification
- qualification_name, qualification_level
- certificate_number, issuing_authority
- valid_from, valid_to
### 人员 person
- person_name, certificate_type, major
- certificate_number, valid_from, valid_to
### 设备 equipment
- equipment_name, model, quantity, unit, remark
### 规范 standard
- standard_number, standard_name
- publish_date, implement_date, applicable_region

## 3. 电力工程专项增强字段（project上追加）
- voltage_level_kv
- substation_capacity_mva
- line_length_km
- transformer_capacity_mva
- cable_type（可选）

## 4. 关键表格（三类）
- 设备清单：equipment_items
- 人员清单：person_table_items
- 业绩汇总：project_summary_table

## 5. 建议：抽取单元
- 章节级（chapter text）输入 LangExtract/IE
- 关键表格修复仅发单表格文本（脱敏后）
