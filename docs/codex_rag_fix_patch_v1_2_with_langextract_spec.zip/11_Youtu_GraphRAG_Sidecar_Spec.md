# 11 Youtu-GraphRAG Sidecar 接入一页规范（V1.0）
日期：2026-03-01

适用：你们现有专家库主链路 **MinerU →（IE/Embedding）→ Qdrant Hybrid → Rerank → Evidence Pack → LLM**。  
目的：在**不替换现有 RAG 主链路**的前提下，引入 Youtu-GraphRAG 作为 **Sidecar“复杂问题增强检索/推理器”**，用于：
- 多跳推理（人→项目→电压等级→角色→证据页）
- 关系型组合筛选（>=110kV、项目经理、金额范围、资质等级等）
- 现有 dense+sparse 召回 topK 中“证据缺失/噪声过大”的兜底与补充

参考：Youtu-RAG/GraphRAG 开源定位与特性（agentic + graph schema）。

---

## 1) 运行方式
- 部署：Youtu-GraphRAG 独立 Docker 服务（sidecar），与主系统同内网。
- 主系统保持 Qdrant 为主索引；GraphRAG 仅在特定 Query 条件触发（见第 3 节）。
- Sidecar 只输出“证据候选 + 推理线索（可选）”，不直接输出最终答案；最终答案仍由主系统生成并强制引用。

---

## 2) 输入数据（最小可用）
Sidecar 不直接吃 PDF；吃你们的 **标准化文本/结构化资产**：

### 2.1 文本证据库（必须）
- 由 MinerU 输出并清洗后的按页文本（与 citations 对齐）：
  - `/data/docs/<doc_id>/page_001.txt`
  - `/data/docs/<doc_id>/page_002.txt`
  - ...
- 每页文件首行建议写入元信息（可选）：`DOC_ID=... PAGE_NO=... DOC_NAME=...`

### 2.2 结构化资产（建议）
将你们 Postgres 的实体/关系导出为 GraphRAG 可用的轻量 JSON（用于图构建或 query 约束）：
- `entities.jsonl`：person/project/equipment/qualification...
- `relations.jsonl`：PERSON_TO_PROJECT、PERSON_ROLE、COMPANY_TO_QUALIFICATION...
- 字段最少包含：`id`, `type`, `name`, `properties`, `evidence(doc_id,page_no,excerpt)`

> V1.0 允许只提供“按页文本”；结构化资产留作 V1.1 增强。

---

## 3) 触发策略（什么时候走 GraphRAG）
实现：`should_use_graphrag(question, parsed_filter_spec) -> bool`

建议触发条件（满足任意一条）：
1. **多条件组合**：出现 >=2 个结构约束（如人名+角色+kV/金额）
2. **关系型意图**：包含“担任过/参与过/绑定/关联/属于/负责/项目经理/总工”等
3. **复杂问句**：长度 > 25 字且含多个实体（人/项目/设备）
4. **主链路失败回退**：Qdrant top20 中 evidence_score 低（见 6.3）或命中率历史偏低的 query 类别

feature flag：
- `ENABLE_YOUTU_GRAPHRAG=false`（默认关闭）
- `GRAPHRAG_TRIGGER_MODE=rule|fallback|always`（默认 rule）

---

## 4) Sidecar API 契约（主系统 → GraphRAG）
> 若 GraphRAG 自带 API 不完全匹配，建议在 sidecar 外再包一层“适配器网关”，统一接口。

### 4.1 请求：`POST /graphrag/search`
```json
{
  "query_id": "uuid",
  "question": "string",
  "filters": {
    "person_ids": ["p:..."],
    "project_ids": ["pr:..."],
    "roles": ["项目经理"],
    "val_voltage_kv": { "gte": 110 },
    "val_contract_amount_w": { "gte": 5000 }
  },
  "top_n": 50,
  "doc_scope": {
    "doc_types": ["project_proof","person","qualification","tech_plan"],
    "doc_ids": ["optional doc_id whitelist"]
  },
  "return_reasoning": false
}
```

### 4.2 响应：候选证据（必须可映射 citations）
```json
{
  "query_id": "uuid",
  "hits": [
    {
      "doc_id": "doc_1024",
      "doc_name": "重庆江北110kV变电站新建工程业绩证明.pdf",
      "page_no": 12,
      "score": 0.91,
      "excerpt": "任命张建国同志担任...项目经理...110kV...",
      "source_path": "/data/docs/doc_1024/page_012.txt",
      "signals": {
        "entities": ["张建国","重庆江北110kV变电站新建工程"],
        "relations": ["PERSON_ROLE_PROJECT"],
        "numbers": ["110kV","5000万元"]
      }
    }
  ],
  "debug": {
    "used_schema": "power_schema_v1",
    "latency_ms": 820
  }
}
```

---

## 5) 主系统融合方式（GraphRAG 与现有 RAG）
### 5.1 作为“第四路候选”加入融合
你们已有：`dense_hits`, `sparse_hits(Sirchmunk/PG)`, `structured_hits(PG资产)`  
新增：`graphrag_hits`

融合：`rrf_fuse([dense, sparse, structured, graphrag]) -> fused`  
建议 RRF 权重（可选）：对 graphrag_hits 给予轻微加成（例如 rank 乘 0.9），仅在命中质量验证后启用。

### 5.2 去重规则
- 同 `doc_id + page_no` 合并，score 取 max；excerpt 选更“证据句”的版本。
- 将 graphrag 的 `signals` 合并进 payload（用于后续调试与解释）。

---

## 6) Evidence Pack 组装与“证据质量”
### 6.1 证据包组装
`fused_top20 → build_evidence_pack()`：
- 必须包含 citations（doc_name/page_no/excerpt）
- 支持“可展开上下文”：从 `page_0xx.txt` 前后各取 N 行作为 context_before/after

### 6.2 生成约束
生成模型 system prompt 中加入：
- 只能依据 evidence_pack 回答
- 每条关键结论后附 1~N 引用
- 若 evidence 不足：输出“未在资料中找到”并给出可追问建议

### 6.3 evidence_score（用于 fallback 触发）
对 Qdrant top20 计算证据质量：
- 命中关键字段（kV/金额/证书号/角色）数
- excerpt 覆盖度（问题关键词覆盖率）
- 去噪后有效字数
若低于阈值，则触发 GraphRAG fallback（即使规则未触发）。

---

## 7) A/B 评测与上线策略（必须）
### 7.1 评测集
- 30~100 个真实投标/资质问题（含复杂组合问句）
- 标注：正确 doc_id/page_no（1~3 条）

### 7.2 指标
- Recall@10、MRR
- EvidenceHitRate（top10 是否包含正确页）
- 关键字段 fatal error 触发率（kV/资质等级/金额数量级）
- 延迟（P95）与成本（token）

### 7.3 灰度
- 先对“复杂问句”小流量开启：`GRAPHRAG_TRIGGER_MODE=rule`
- 观察 1 周（或 N 次查询）后再扩大范围
- 必须可一键回滚：`ENABLE_YOUTU_GRAPHRAG=false`

---

## 8) Codex TODO（改动点清单）
新增文件（建议）：
- `retrieval/graphrag/graphrag_client.py`
- `retrieval/graphrag/trigger.py`
- `retrieval/fusion/rrf.py`（已有则复用）
- `eval/offline_retrieval_eval.py`（扩展：加入 graphrag route 对比）

修改点：
- `search()`：在三路召回后按 trigger 追加 graphrag 候选，再统一 fuse+rerank+evidence_pack。
- 配置：新增 `ENABLE_YOUTU_GRAPHRAG` / `GRAPHRAG_BASE_URL` / `GRAPHRAG_TIMEOUT_MS`。

---

## 9) 兼容你们“关系/数值过滤”方案
你们已在 Qdrant payload 内打平：`entity_*_ids`, `rel_*`, `val_*`。  
GraphRAG 的 `filters` 字段应沿用同一套 parse_filter_spec 输出，做到：
- 同一个 query analyzer 同时驱动 Qdrant filter 与 GraphRAG filters
- 统一 ID/Hash（B方案），避免名称歧义
