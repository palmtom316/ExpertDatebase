# 12 LangExtract IE Sidecar 工程规范（V1.0）
日期：2026-03-01

适用：你们现有专家库主链路 **MinerU →（清洗/分块）→（IE/Embedding）→ Qdrant Hybrid → Rerank → Evidence Pack → LLM**。  
目的：以**可插拔、可灰度、可回滚**的方式引入 LangExtract（Google 开源的结构化抽取库）作为 **IE 抽取执行器**，重点提升：
- 关键字段抽取质量（电力专项：kV/MVA/线路长度/金额数量级/资质等级）
- 轻关系抽取（PERSON_TO_PROJECT、PERSON_ROLE、EQUIPMENT_TO_PROJECT）
- 抽取结果的 **更精确溯源（char offset / page mapping）** 与审查效率

**注意**：LangExtract 不替代 OCR/表格解析；仅替代/补充你们的 IE 抽取引擎。

参考：LangExtract 项目开源定位（schema-driven extraction + grounding + 长文分块/多 pass + 可视化报告）。

---

## 1) 运行方式与边界
### 1.1 两种部署模式（任选其一）
A. **In-Process Engine（推荐 V1.0）**
- LangExtract 作为主 worker 的一个 Python 依赖包，直接在 worker 进程内调用。
- 优点：部署最简单，无额外服务；缺点：抽取吞吐受 worker 资源限制。

B. **IE Sidecar Service（推荐 V1.1+）**
- LangExtract 运行在独立容器中，提供 HTTP API（便于扩缩容、隔离故障、统一审计日志）。
- 本规范同时给出 sidecar API 契约，便于未来升级为独立服务。

### 1.2 边界清晰
- 输入：来自 MinerU 的 **按页文本** 或 **章节文本**（已清洗），以及可选的表格结构摘要。
- 输出：遵循你们统一 `ie_schema_v1.json` 的字段 + `evidence`（doc_id/page_no/excerpt/offset）。
- 不做：embedding、向量入库、检索、rerank。

---

## 2) 输入/输出数据结构（统一协议）
### 2.1 输入（主系统 → LangExtract）
`POST /ie/langextract/extract`
```json
{
  "job_id": "uuid",
  "doc_id": "doc_1024",
  "doc_name": "xxx.pdf",
  "doc_type": "project_proof|qualification|person|equipment|tech_plan|standard",
  "language": "zh",
  "chunk": {
    "chunk_id": "c_000123",
    "chunk_type": "chapter|evidence|table_row|page",
    "page_range": [12, 13],
    "title_path": ["第三章", "一、工程概况"],
    "text": "string (cleaned)",
    "tables": [
      {
        "table_id": "t_045",
        "table_kind": "equipment_list|person_list|performance_summary|other",
        "header": ["序号","设备名称","规格型号","单位","数量","备注"],
        "rows": [
          ["1","主变压器","SZ11-50000/110","台","2","..."]
        ]
      }
    ]
  },
  "schema_id": "ie_schema_v1",
  "task": {
    "mode": "extract_fields|extract_relations|extract_both",
    "field_groups": ["power_critical","project_core","qualification_core"],
    "relation_types": ["PERSON_TO_PROJECT","EQUIPMENT_TO_PROJECT","COMPANY_TO_QUALIFICATION"]
  },
  "options": {
    "max_passes": 2,
    "enable_html_report": false,
    "grounding": "char_offset",
    "strict_json": true
  }
}
```

说明：
- `chunk.text` 必须是 **去页眉页脚/水印/乱码过滤后**的文本。
- `tables` 可为空；若存在，建议仅提供“结构化行摘要”，不要塞原始 Markdown 大表。

### 2.2 输出（LangExtract → 主系统）
```json
{
  "job_id": "uuid",
  "doc_id": "doc_1024",
  "chunk_id": "c_000123",
  "results": {
    "fields": {
      "project_name": {
        "value": "重庆江北110kV变电站新建工程",
        "confidence": 0.86,
        "evidence": [{
          "doc_id": "doc_1024",
          "page_no": 12,
          "char_start": 531,
          "char_end": 556,
          "excerpt": "……重庆江北110kV变电站新建工程……"
        }]
      },
      "voltage_level_kv": {
        "value": 110,
        "confidence": 0.92,
        "evidence": [{
          "page_no": 12,
          "char_start": 488,
          "char_end": 492,
          "excerpt": "……110kV……"
        }]
      }
    },
    "relations": [
      {
        "relation_type": "PERSON_TO_PROJECT",
        "source": {"entity_type":"person","entity_name":"张建国","reference_id":"person_012"},
        "target": {"entity_type":"project","entity_name":"重庆江北110kV变电站新建工程","reference_id":"proj_045"},
        "properties": {"role_in_project":"项目经理","appointment_date":"2021-05-10"},
        "confidence": 0.81,
        "evidence": [{
          "page_no": 12,
          "char_start": 600,
          "char_end": 640,
          "excerpt": "任命张建国同志担任…项目经理…"
        }]
      }
    ]
  },
  "debug": {
    "passes": 2,
    "latency_ms": 740,
    "model": "provider/model-id"
  }
}
```

---

## 3) Grounding：char offset → page_no 映射（必须实现）
LangExtract 常返回字符级 offset；你们需要可追溯到页码与引用片段。

### 3.1 输入文本组织（关键）
为确保 offset 可映射到页：主系统在调用前，应将 chunk.text 组织为：
- 以 `\n\n[[PAGE:12]]\n` 作为页面分隔标记（或其他唯一标记）
- 每页文本拼接时记录 `page_start_char`（prefix sum）

示例：
```
[[PAGE:12]]
...page12 text...
[[PAGE:13]]
...page13 text...
```

### 3.2 映射算法（伪代码）
- 构建 `page_spans = [(page_no, start_char, end_char)]`
- 对 evidence 的 `char_start/char_end` 二分定位所在 page span
- `excerpt` 由原文 substring + 适度扩展窗口生成（±N 字）

> 这样可保证 citations 的 doc_id/page_no/excerpt 与 UI 展示一致。

---

## 4) 多 Pass 抽取策略（解决漏召回）
你们的痛点之一是长文漏抽/断层；建议启用最多 2 passes：

### Pass 1：高精度（strict）
- 强约束输出 schema
- 只抽取最核心字段（power_critical / project_core）
- 温度低、避免幻觉

### Pass 2：补漏（recall）
- 仅对 Pass1 缺失字段做 targeted extraction（给出“缺失字段清单”）
- 允许更宽松的匹配（但必须带 evidence）
- 若仍无 evidence，字段必须返回 null（不要编造）

合并规则：
- 同字段多候选：优先 evidence 更长/更靠近关键关键词的；或 confidence 更高。
- 数值字段（kV、金额）优先用正则校验 + 单位归一化（见 5.3）。

---

## 5) 关键字段与电力专项规范（必须内置校验）
### 5.1 Fatal fields（致命错误字段）
下列字段一旦抽取与 truth 不符（在评测中）应触发 fatal：
- `voltage_level_kv`
- `qualification_grade`
- `contract_amount`（数量级/币种）

### 5.2 单位与归一化
- kV：统一为整数（110/220/35）
- 金额：统一为“万元”或“元”（项目内统一一种），并保留原文金额字符串
- 里程：km

### 5.3 校验规则（示例）
- `voltage_level_kv` 必须匹配 `(?<!\d)(35|66|110|220|330|500|750|1000)\s*kV`
- 金额必须包含单位（元/万元/亿元）或上下文币种；否则 confidence 降级并要求人工抽查

---

## 6) 与你们现有系统的集成点（代码改动）
### 6.1 新增模块（建议路径）
- `ie/engines/langextract_engine.py`（in-process）
- `ie/sidecars/langextract_client.py`（sidecar http client）
- `ie/grounding/page_offset_mapper.py`
- `ie/validators/power_field_validator.py`
- `configs/langextract_policy_v1.json`（何时启用、字段组、pass 策略）

### 6.2 主 pipeline 改动
在 ingest 或异步 IE worker 中新增：
- 依据 feature flag 决定使用 `custom_ie` 还是 `langextract_ie`（或双跑对比）
- 把抽取结果写入：
  1) Postgres 资产表（fields/relations）
  2) Qdrant payload（轻关系/数值：entity_ids、rel_*、val_*）

### 6.3 Feature flags（必须）
- `ENABLE_LANGEXTRACT=false`
- `LANGEXTRACT_MODE=inprocess|sidecar`（默认 inprocess）
- `LANGEXTRACT_MAX_PASSES=2`
- `LANGEXTRACT_ENABLE_HTML_REPORT=false`

---

## 7) Sidecar API（若启用独立服务）
### 7.1 服务端要求
- 纯 CPU 可跑；并发建议限制 1~2（避免内存压力）
- 超时控制：默认 30s；长文可拆小 chunk

### 7.2 必须日志
- job_id、doc_id、chunk_id
- latency_ms、model、token
- 抽取字段数量、relations 数量
- evidence 覆盖率（evidence count / fields count）

---

## 8) 审查与抽查（Review）
你们当前是人工抽查不审批：
- LangExtract 输出的 evidence（page_no + excerpt + offset）直接用于 Review UI 展示
- 若开启 html report：保存到对象存储或本地路径供下载（内网）
- 抽查策略：fatal fields 或 low confidence 自动入“抽查队列”

---

## 9) 离线评测与 A/B（必须）
### 9.1 双跑对比
- 同一份文档/同一组问题：custom_ie vs langextract_ie
- 指标：FieldAcc、SourceAcc、FatalErrorRate、RelationAcc

### 9.2 门槛
- 若 fatal error 率上升：立刻回滚（feature flag off）
- 若 FieldAcc 提升且 SourceAcc 不下降：可扩大启用范围

---

## 10) 与 Sirchmunk / GraphRAG 的协同
- LangExtract 的 fields/relations 将写入 Qdrant payload（`rel_*`, `val_*`），用于更强的 filter。
- Sirchmunk 负责 sparse evidence 召回；LangExtract 提供更准确的结构化过滤条件。
- GraphRAG sidecar 的 `filters` 复用同一套 parse_filter_spec 输出，形成一致的实体/数值约束。

