# Codex 代码修订补丁包（RAG 索引效果救火 + LangExtract/Sirchmunk 接入方案）
版本：v1
适用：你们已上线的 **MinerU + LLM + Embedding + Rerank + Qdrant** 专家库系统（内网 Docker）
目标：把“完全不可用”的检索链路修到“可用且可评测”，并以最小风险方式引入 **Hybrid Retrieval**、**Sirchmunk sidecar（稀疏证据召回）** 与 **LangExtract（可插拔 IE 引擎）**。

---

## 0. 总体原则（必须遵守）
1. **先救召回，再谈生成**：先把 Recall@10 拉起来，再优化答案生成。
2. **不推翻现有架构**：新增 sidecar/插件/策略，不替换主流程。
3. **可观测 + 可回滚**：每一步都要有离线评测与开关（feature flag）。
4. **强引用**：最终回答必须有 1~N 条引用（doc+page+excerpt）。

---

## 1) 你们当前最可能的根因（按优先级）
Codex 需要优先检查/修订以下问题：
- [ ] 文本清洗不足：页眉页脚/水印重复、乱码率高、断字严重 → embedding 失效
- [ ] chunking 仅按长度：结构边界（标题/条款/表格行）未保留 → 关键字段断裂
- [ ] 仅 dense 向量召回：缺 sparse/BM25 → 证书号/型号/kV/金额/项目名等检索崩
- [ ] rerank 候选集太小或太脏：topK 太小、重复块污染 → rerank 无法挽救
- [ ] 无离线评测：无法定位是召回错还是生成错

---

## 2) P0（必须做）：三路召回 → 融合 → rerank → 证据包
### 2.1 Query Analyzer（规则提取 filters）
实现函数：`parse_filter_spec(question) -> (filter_json, sparse_query, dense_query_text)`
- 抽取：人名、角色、kV、金额（万/亿）、项目名关键词
- 产物：
  - `filter_json`：供 Qdrant payload filter（你们已做 B方案 ID/Hash）
  - `sparse_query`：供 Sirchmunk/BM25
  - `dense_query_text`：供 embedding

### 2.2 Dense Retriever（Qdrant）
保持现有：`qdrant_dense_search(query_vector, filter_json, top_n=200)`

### 2.3 Sparse Retriever（优先 Sirchmunk；备选 PG tsvector）
#### A) Sirchmunk Sidecar（推荐）
新增一个 sidecar 服务：`sirchmunk_search(query_text, top_n=200)`
输入：query_text（从 question + 关键短语生成）  
输出：`[{doc_id, page_no, excerpt, score, source_path}]`

**关键：页码映射**
- 入库时将 MinerU 产物按页落盘：`/data/docs/<doc_id>/page_001.txt`...
- sidecar 返回命中的文件名/行号 → 解析出 `page_no`，用于 citations。

#### B) PG tsvector（备选，若不想引入 Sirchmunk）
- 表：`doc_pages(doc_id, page_no, text, tsv)`
- 索引：GIN(tsv)
- 查询：`websearch_to_tsquery` / `plainto_tsquery`

### 2.4 结构化召回（PG 资产库优先路由）
实现：`structured_lookup(question) -> candidates[]`
- 对证书号/标准号/项目编号/人员证书等：优先在 PG 结构化表中查
- 返回证据页码与摘要，加入候选

### 2.5 融合（RRF）
实现：`rrf_fuse([dense_candidates, sparse_candidates, structured_candidates], k=60) -> fused_candidates`
- 每路候选按 rank 转为 RRF score
- 去重：同 doc_id+page_no+chunk_id 只保留最高分

### 2.6 Cross-Encoder Rerank（可选但强烈建议）
实现：`rerank(question, fused_candidates, top_k=20)`
- 先 fuse top200，再 rerank 到 top20

### 2.7 Evidence Pack（必须）
实现：`build_evidence_pack(top_candidates) -> evidence_pack`
- 每条证据：{doc_id, doc_name, page_no, excerpt, chunk_id?, payload?}
- 生成模型只允许基于 evidence_pack 回答（强引用）

---

## 3) P1（强烈建议）：结构感知 chunking + 质量闸门
### 3.1 Chunking
实现策略：
- 标题/条款边界优先：`第X章/第X条/一、/（一）/1.1`
- 表格按行或小块切，不把整张表 raw md 直接入库
- size：中文 400~800 字，overlap：80~150 字（可配置）

### 3.2 质量闸门（不达标不入向量库）
实现：`chunk_quality_score(text) -> score + reason`
拒绝/降权规则：
- 乱码率过高、重复页眉页脚、高重复 n-gram
- 过短且无关键字段
- 仅包含页码/水印

---

## 4) LangExtract（可插拔 IE 引擎）接入（V1.1）
目标：提升关键字段/关系抽取质量，间接提升 Hybrid Filter 的有效性。
接入方式：不替换现有 IE，只增加 engine：
- `ie_extract(engine="custom"|"langextract")`

启用范围（默认关闭）：
- 电力关键字段：kV、MVA、线路长度、金额级别
- 轻关系：PERSON_TO_PROJECT（项目经理/总工）
- 文档质量 C、章节超长（>12k）

输出统一映射到你们 schema：
- 字段值 + page_no + excerpt +（可选）char_offset

---

## 5) Sirchmunk Sidecar 部署建议（最小可用）
目录约定：
- `/data/docs/<doc_id>/page_001.txt`
- `/data/docs/<doc_id>/page_002.txt`
...
Sidecar API（建议）：
- `POST /search` { query, top_n, doc_types?, filters? } -> hits[]

hits[] 最少字段：
- `doc_id`
- `page_no`
- `score`
- `excerpt`
- `source_path`（用于追踪）

---

## 6) 离线评测（必须加入 CI 或 nightly）
最小评测集：30~100 个真实问题（投标工程师提供）
每题标注：正确 doc_id + page_no（1~3条即可）

指标：
- Recall@5 / Recall@10 / MRR
- 证据命中率（top10 是否包含正确页）
- Fatal Error（电压等级/资质等级/金额数量级错误）触发率

输出：HTML/JSON 报告 + 失败样本列表

---

## 7) Codex 需要改哪些代码（TODO 清单）
### 7.1 新增模块（建议路径）
- `retrieval/query_analyzer.py`
- `retrieval/sparse/sirchmunk_client.py`
- `retrieval/sparse/pg_bm25.py`（可选）
- `retrieval/fusion/rrf.py`
- `retrieval/rerank/reranker.py`
- `retrieval/evidence_pack.py`
- `ingest/chunking/structure_chunker.py`
- `ingest/quality_gate.py`
- `ie/engines/langextract_engine.py`（可选）
- `eval/offline_retrieval_eval.py`

### 7.2 修改现有链路
- `search()`：从“单路 dense→rerank”改为“三路召回→融合→rerank→证据包→生成”
- `ingest()`：在入库前做质量闸门与结构 chunking；表格走结构化摘要入库

### 7.3 Feature flags（必须）
- `ENABLE_SIRCHMUNK=false`
- `ENABLE_PG_BM25=true/false`
- `ENABLE_LANGEXTRACT=false`
- `ENABLE_RERANK=true`
- `ENABLE_STRUCTURED_LOOKUP=true`

---

## 8) 最小交付验收（Definition of Done）
- [ ] 离线评测集上：Recall@10 相比当前提升明显（至少 +30% 绝对值或达到可用阈值）
- [ ] 关键字段问答（kV/金额/证书号/项目经理）能稳定给出引用页
- [ ] 线上日志能定位：召回候选数、各路来源占比、rerank 前后变化
- [ ] 可一键关闭 Sirchmunk/LangExtract 回到旧链路（可回滚）


---

## 9) 可选增强：Youtu-GraphRAG Sidecar
见 `11_Youtu_GraphRAG_Sidecar_Spec.md`：用于复杂关系/多跳推理问题的 sidecar 检索增强（可灰度、可回滚）。


---

## 10) 可选增强：LangExtract IE 执行器
见 `12_LangExtract_IE_Sidecar_Spec.md`：可插拔 IE 引擎（in-process/sidecar），提供字段/关系抽取、多 pass、char offset→page 映射、fatal 校验与 A/B 双跑规范。
