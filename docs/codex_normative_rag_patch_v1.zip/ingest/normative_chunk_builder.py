\
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
import re
from .normative_clause_parser import ClauseNode
from .normative_tree import ClauseTree, get_ancestors

@dataclass
class ClauseChunk:
    chunk_id: str
    doc_id: str
    page_no: int
    text: str
    payload: Dict[str, Any]

_num_re = re.compile(r"(?:\\b\\d+(?:\\.\\d+)?\\b)")

def extract_numbers(text: str) -> List[float]:
    out = []
    for m in _num_re.finditer(text):
        try:
            out.append(float(m.group(0)))
        except Exception:
            pass
    return out

def detect_mandatory(clause_id: str, mandatory_set: Optional[set]) -> bool:
    return bool(mandatory_set and clause_id in mandatory_set)

def build_clause_text(tree: ClauseTree, node: ClauseNode, context_depth: int = 2) -> str:
    lines: List[str] = []
    for aid in get_ancestors(tree, node.clause_id, depth=context_depth):
        a = tree.by_id.get(aid)
        if a:
            lines.append(f"{a.clause_id} {a.title}".strip())
    lines.append(f"{node.clause_id} {node.title}".strip())
    if node.body:
        lines.append(node.body.strip())
    return "\\n".join([l for l in lines if l]).strip()

def build_clause_chunks(
    nodes: List[ClauseNode],
    tree: ClauseTree,
    doc_meta: Dict[str, Any],
    context_depth: int = 2,
    mandatory_clause_ids: Optional[List[str]] = None,
) -> List[ClauseChunk]:
    mandatory_set = set(mandatory_clause_ids or [])
    chunks: List[ClauseChunk] = []
    for n in nodes:
        text = build_clause_text(tree, n, context_depth=context_depth)
        payload = {
            "doc_id": n.doc_id,
            "doc_type": doc_meta.get("doc_type", "spec"),
            "doc_name": doc_meta.get("doc_name"),
            "page_no": n.page_start,
            "chunk_type": "clause",
            "clause_id": n.clause_id,
            "clause_id_base": n.clause_id_base,
            "clause_sub": n.clause_sub,
            "clause_level": n.level,
            "parent_clause_id": n.parent_id,
            "is_mandatory": detect_mandatory(n.clause_id, mandatory_set),
            "val_numbers": extract_numbers(text),
        }
        chunk_id = f"{n.doc_id}::clause::{n.clause_id}"
        chunks.append(ClauseChunk(chunk_id=chunk_id, doc_id=n.doc_id, page_no=n.page_start, text=text, payload=payload))
    return chunks

def chunk_to_dict(c: ClauseChunk) -> Dict[str, Any]:
    return asdict(c)
