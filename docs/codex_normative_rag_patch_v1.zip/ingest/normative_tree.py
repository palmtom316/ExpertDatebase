\
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional
from .normative_clause_parser import ClauseNode

@dataclass
class ClauseTree:
    children: Dict[str, List[str]]
    parent: Dict[str, Optional[str]]
    by_id: Dict[str, ClauseNode]

def build_normative_tree(nodes: List[ClauseNode]) -> ClauseTree:
    by_id = {n.clause_id: n for n in nodes}
    parent: Dict[str, Optional[str]] = {}
    children: Dict[str, List[str]] = {}

    for n in nodes:
        pid = n.parent_id
        parent[n.clause_id] = pid
        if pid:
            children.setdefault(pid, []).append(n.clause_id)

    def key(cid: str):
        base = by_id[cid].clause_id_base
        parts = []
        for p in base.split("."):
            try:
                parts.append(int(p))
            except Exception:
                parts.append(p)
        sub = by_id[cid].clause_sub
        if sub is not None:
            try:
                parts.append(int(sub))
            except Exception:
                parts.append(sub)
        return parts

    for pid, ch in children.items():
        ch.sort(key=key)

    return ClauseTree(children=children, parent=parent, by_id=by_id)

def get_ancestors(tree: ClauseTree, clause_id: str, depth: int = 2) -> List[str]:
    out = []
    cur = clause_id
    for _ in range(depth):
        p = tree.parent.get(cur)
        if not p:
            break
        out.append(p)
        cur = p
    out.reverse()
    return out

def get_children(tree: ClauseTree, clause_id: str) -> List[str]:
    return list(tree.children.get(clause_id, []))
