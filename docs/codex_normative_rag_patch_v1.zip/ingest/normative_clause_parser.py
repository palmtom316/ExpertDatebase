\
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict
import re

@dataclass
class Page:
    doc_id: str
    page_no: int  # 1-based
    text: str     # per-page text

@dataclass
class ClauseNode:
    doc_id: str
    clause_id: str            # e.g., "4.12.1(3)" or "1.0.1"
    clause_id_base: str       # e.g., "4.12.1"
    clause_sub: Optional[str] # e.g., "3"
    level: int                # number of dots + 1 (base)
    title: Optional[str]      # may be None
    body: str                 # clause body text (no header/footer)
    page_start: int           # 1-based page index
    page_end: int
    parent_id: Optional[str] = None  # computed later

def compile_rejectors(reject_line_regexes: List[str]) -> List[re.Pattern]:
    return [re.compile(r, re.IGNORECASE) for r in reject_line_regexes]

def clean_page_text(text: str, rejectors: List[re.Pattern]) -> str:
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        if any(r.search(s) for r in rejectors):
            continue
        if len(s) <= 3 and all(ch in "—-_=*·•." for ch in s):
            continue
        lines.append(s)
    return "\n".join(lines)

def parse_normative_clauses(
    pages: List[Page],
    clause_id_regex: str,
    reject_line_regexes: List[str],
    max_title_len: int = 48,
) -> List[ClauseNode]:
    \"\"\"Parse 1 / 1.1 / 1.1.1 / 4.12.1(3) style clauses.\"\"\"
    id_re = re.compile(clause_id_regex)
    rejectors = compile_rejectors(reject_line_regexes)

    def is_probable_title(rest: str) -> bool:
        if not rest:
            return False
        if len(rest) > max_title_len:
            return False
        if rest.endswith(("。", ".", "；", ";", "：", ":")):
            return False
        digit_ratio = sum(ch.isdigit() for ch in rest) / max(1, len(rest))
        if digit_ratio > 0.25:
            return False
        return True

    nodes: List[ClauseNode] = []
    current: Optional[ClauseNode] = None
    buf: List[str] = []

    for page in pages:
        cleaned = clean_page_text(page.text, rejectors)
        for raw_line in cleaned.splitlines():
            m = id_re.match(raw_line)
            if m:
                if current:
                    current.body = "\\n".join(buf).strip()
                    current.page_end = page.page_no
                    nodes.append(current)
                buf = []

                cid_base = m.group("id")
                sub = m.groupdict().get("sub")
                rest = (m.groupdict().get("rest") or "").strip()
                clause_id = cid_base + (f"({sub})" if sub else "")
                level = cid_base.count(".") + 1

                title = rest if is_probable_title(rest) else None
                if title is None and rest:
                    buf.append(rest)

                current = ClauseNode(
                    doc_id=page.doc_id,
                    clause_id=clause_id,
                    clause_id_base=cid_base,
                    clause_sub=sub,
                    level=level,
                    title=title,
                    body="",
                    page_start=page.page_no,
                    page_end=page.page_no,
                )
            else:
                if current:
                    buf.append(raw_line)

    if current:
        current.body = "\\n".join(buf).strip()
        nodes.append(current)

    for n in nodes:
        base = n.clause_id_base
        if "." in base:
            n.parent_id = ".".join(base.split(".")[:-1])
        else:
            n.parent_id = None
        if n.clause_sub:
            n.parent_id = base

    return nodes

def node_to_dict(n: ClauseNode) -> Dict:
    return asdict(n)
