# 规范类文档 RAG 改造：完整代码补丁包（v1）

目标：把“规范/标准/规程/制度”这类 **1 / 1.1 / 1.1.1 / 4.12.1(3)** 结构的 PDF，从“按长度切块 + 向量召回”升级为：

- **条款级索引（clause-level chunks）**
- **条款树（clause_tree）用于父子上下文展开**
- **强制性条文打标（is_mandatory）**
- **查询路由（命中条款号 → 精确 filter；命中‘强制’→ mandatory filter）**
- **Hybrid 支持（dense + sparse / 你们现有 Sirchmunk/PG）**
- **Evidence Pack 引用页 + 上下文展开（context_before/after）**

本补丁是“增量式接入”，不要求推翻现有 Qdrant/Worker/Search 结构。
你需要把以下文件合入你们代码仓库，并在 ingest/search 链路接入对应函数。

---

## 目录结构
- `configs/normative_parser.yaml`：条款正则与清洗规则
- `ingest/normative_clause_parser.py`：条款解析器（从 MinerU page texts 或 markdown 解析 clause 节点）
- `ingest/normative_tree.py`：构建条款树 + 父子索引
- `ingest/normative_chunk_builder.py`：生成 clause chunk（带祖先标题链）+ payload
- `retrieval/normative_query_router.py`：查询路由与 filter 生成（clause_id/mandatory）
- `retrieval/normative_context_expander.py`：根据 clause_tree 展开父/子上下文
- `retrieval/normative_search_pipeline.py`：示例：normative 文档的检索管线封装（可嵌入你们 search()）
- `tests/test_normative_parser.py`：解析器单测样例（用你们真实样本替换 fixtures）

---

## Feature Flags（建议）
- `ENABLE_NORMATIVE_CLAUSE_INDEX=true`
- `NORMATIVE_COLLECTION=qdrant_collection_normative_clause`
- `NORMATIVE_TREE_TABLE=normative_clause_tree`
- `NORMATIVE_CONTEXT_DEPTH=2`
- `NORMATIVE_CONTEXT_LINES=10`（上下文展开前后行数）

---

## 接入点（最小改动）

### A) Ingest/Worker（入库）
1. 在文档类型判定为 `doc_type == "spec"` 时，调用：
   - `parse_normative_clauses(pages)` → clause_nodes
   - `build_normative_tree(clause_nodes)` → tree
   - `build_clause_chunks(clause_nodes, tree, doc_meta)` → chunks
2. 写入：
   - clause chunks → Qdrant collection（独立 collection 或同 collection 不同 chunk_type）
   - tree → Postgres 表 `normative_clause_tree`（或 json 文件）

### B) Query/Search（检索）
1. 在 query analyzer 后，增加：
   - `route_normative_query(question)` 返回 (route, filter_json, clause_id)
2. 如果 route 为 `CLAUSE_ID_EXACT`：走 Qdrant filter `clause_id == xxx`
3. 如果命中“强制/必须执行”：filter `is_mandatory = true`
4. 返回 topK clause hits 后，用：
   - `expand_normative_context(hits, tree, depth=2)` 补齐祖先标题/同级/子条款（可选）
5. 统一进入你们 existing rerank + evidence pack

---

## 重要约束（规范类必须）
- 不要按 token/长度切条款
- 必须清洗页眉/页脚/水印
- clause chunk 的文本必须包含“祖先标题链 + 当前条款编号 + 正文”
- 生成回答必须输出 clause_id + 引用页（你们 evidence pack 已支持）
