\
import pytest
from ingest.normative_clause_parser import Page, parse_normative_clauses
from ingest.normative_tree import build_normative_tree

def test_parse_simple_clauses():
    pages = [
        Page(doc_id="DOC", page_no=1, text="1 总则\\n1.0.1 本规范适用于……\\n1.0.2 术语……\\n"),
        Page(doc_id="DOC", page_no=2, text="2 基本规定\\n2.1.1 运输倾斜角不得超过15°。\\n2.1.2 ……\\n"),
    ]
    nodes = parse_normative_clauses(
        pages,
        clause_id_regex=r"^\\s*(?P<id>\\d+(?:\\.\\d+)*)(?:\\((?P<sub>[0-9A-Za-z]+)\\))?\\s*(?P<rest>.*)$",
        reject_line_regexes=[],
    )
    assert any(n.clause_id == "1" for n in nodes)
    assert any(n.clause_id == "1.0.1" for n in nodes)
    assert any(n.clause_id == "2.1.1" for n in nodes)

    tree = build_normative_tree(nodes)
    assert tree.parent["1.0.1"] == "1.0"
    assert tree.parent["2.1.1"] == "2.1"

def test_sub_item_parent():
    pages = [Page(doc_id="DOC", page_no=1, text="4.12.1(3) 必须……\\n4.12.1(5) 不得……\\n")]
    nodes = parse_normative_clauses(
        pages,
        clause_id_regex=r"^\\s*(?P<id>\\d+(?:\\.\\d+)*)(?:\\((?P<sub>[0-9A-Za-z]+)\\))?\\s*(?P<rest>.*)$",
        reject_line_regexes=[],
    )
    for n in nodes:
        assert n.parent_id == "4.12.1"
