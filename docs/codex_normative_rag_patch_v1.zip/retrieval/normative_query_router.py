\
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any
import re

CLAUSE_ID_IN_QUERY = re.compile(r"(?P<id>\\d+(?:\\.\\d+)+)(?:\\((?P<sub>[0-9A-Za-z]+)\\))?")
MANDATORY_HINT = re.compile(r"(强制性条文|强制条文|必须执行|一票否决|不得|必须)", re.IGNORECASE)

@dataclass
class NormativeRoute:
    route: str  # CLAUSE_ID_EXACT | MANDATORY_FILTER | NORMAL
    clause_id: Optional[str]
    filter_json: Optional[Dict[str, Any]]

def route_normative_query(question: str) -> NormativeRoute:
    m = CLAUSE_ID_IN_QUERY.search(question)
    if m:
        base = m.group("id")
        sub = m.groupdict().get("sub")
        clause_id = base + (f"({sub})" if sub else "")
        return NormativeRoute(
            route="CLAUSE_ID_EXACT",
            clause_id=clause_id,
            filter_json={"must": [{"key": "clause_id", "match": {"value": clause_id}}]},
        )

    if MANDATORY_HINT.search(question):
        return NormativeRoute(
            route="MANDATORY_FILTER",
            clause_id=None,
            filter_json={"must": [{"key": "is_mandatory", "match": {"value": True}}]},
        )

    return NormativeRoute(route="NORMAL", clause_id=None, filter_json=None)
