\
from __future__ import annotations
from typing import Any, Dict, List
from dataclasses import dataclass

from retrieval.normative_query_router import route_normative_query
from retrieval.normative_context_expander import Evidence, expand_normative_context

@dataclass
class SearchResult:
    evidences: List[Evidence]
    debug: Dict[str, Any]

def normative_search(question: str, embed_fn, qdrant_search_fn, tree, top_k: int = 20, context_depth: int = 2) -> SearchResult:
    \"\"\"
    embed_fn(question) -> vector
    qdrant_search_fn(vector, filter_json, top_k) -> List[Evidence]
    \"\"\"
    route = route_normative_query(question)
    vec = embed_fn(question)
    hits = qdrant_search_fn(vec, route.filter_json, top_k)
    hits = expand_normative_context(hits, tree, depth=context_depth, include_children=False)
    return SearchResult(
        evidences=hits,
        debug={"route": route.route, "clause_id": route.clause_id, "filter_json": route.filter_json},
    )
