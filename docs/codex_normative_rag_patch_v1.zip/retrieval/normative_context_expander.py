\
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from ingest.normative_tree import ClauseTree, get_ancestors, get_children

@dataclass
class Evidence:
    doc_id: str
    doc_name: Optional[str]
    page_no: int
    excerpt: str
    payload: Dict[str, Any]

def expand_normative_context(
    hits: List[Evidence],
    tree: ClauseTree,
    depth: int = 2,
    include_children: bool = False,
    max_children: int = 3,
) -> List[Evidence]:
    out: List[Evidence] = []
    for h in hits:
        cid = h.payload.get("clause_id")
        if not cid or cid not in tree.by_id:
            out.append(h)
            continue

        lines: List[str] = []
        for aid in get_ancestors(tree, cid, depth=depth):
            a = tree.by_id.get(aid)
            if a:
                lines.append(f"{a.clause_id} {a.title}".strip())

        cur = tree.by_id[cid]
        lines.append(f"{cur.clause_id} {cur.title}".strip())
        lines.append(h.excerpt.strip())

        if include_children:
            kids = get_children(tree, cid)[:max_children]
            if kids:
                lines.append("子条款（节选）：")
                for kid in kids:
                    kn = tree.by_id.get(kid)
                    if not kn:
                        continue
                    first = (kn.body or "").strip().splitlines()
                    first = first[0] if first else ""
                    lines.append(f"- {kn.clause_id} {kn.title} {first}".strip())

        out.append(Evidence(
            doc_id=h.doc_id,
            doc_name=h.doc_name,
            page_no=h.page_no,
            excerpt="\\n".join([l for l in lines if l]).strip(),
            payload=h.payload,
        ))
    return out
